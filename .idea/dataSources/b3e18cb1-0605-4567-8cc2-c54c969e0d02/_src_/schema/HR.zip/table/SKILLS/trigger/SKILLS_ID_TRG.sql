CREATE TRIGGER SKILLS_ID_TRG
BEFORE INSERT
  ON SKILLS
FOR EACH ROW
  begin
  if :new.id is null then
    select skills_id_seq.nextval into :new.id from dual;
  end if;
end;
/
