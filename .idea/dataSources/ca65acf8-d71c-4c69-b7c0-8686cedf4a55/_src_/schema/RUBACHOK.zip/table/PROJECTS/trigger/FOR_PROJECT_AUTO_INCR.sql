CREATE TRIGGER FOR_PROJECT_AUTO_INCR
BEFORE INSERT
  ON PROJECTS
FOR EACH ROW
  begin
  if :new.id is null then
    select PROJECTS_ID_AUTO_INCREMENT.NEXTVAL into :new.id from dual;
  end if;
end;
/
