CREATE TRIGGER FOR_AUTO_INCR
BEFORE INSERT
  ON SKILLS
FOR EACH ROW
  begin
  if :new.id is null then
    select AUTO_INCREMENT.NEXTVAL into :new.id from dual;
  end if;
end;
/
