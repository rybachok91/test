CREATE TRIGGER FOR_DEVELOPERS_AUTO_INCR
BEFORE INSERT
  ON DEVELOPERS
FOR EACH ROW
  begin
  if :new.id is null then
    select DEVELOPERS_ID_AUTO_INCREMENT.NEXTVAL into :new.id from dual;
  end if;
end;
/
