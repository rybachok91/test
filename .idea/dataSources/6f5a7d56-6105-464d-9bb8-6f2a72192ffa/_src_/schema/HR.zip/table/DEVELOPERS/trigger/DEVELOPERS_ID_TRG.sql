CREATE TRIGGER DEVELOPERS_ID_TRG
BEFORE INSERT
  ON DEVELOPERS
FOR EACH ROW
  begin
  if :new.id is null then
    select developers_id_seq.nextval into :new.id from dual;
  end if;
end;
/
