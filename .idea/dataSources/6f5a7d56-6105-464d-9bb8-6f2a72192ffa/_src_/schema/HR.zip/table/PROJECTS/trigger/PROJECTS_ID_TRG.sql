CREATE TRIGGER PROJECTS_ID_TRG
BEFORE INSERT
  ON PROJECTS
FOR EACH ROW
  begin
  if :new.id is null then
    select projects_id_seq.nextval into :new.id from dual;
  end if;
end;
/
